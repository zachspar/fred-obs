#!/usr/bin/env python3
"""
Fred API Python Wrapper.
"""
from .api import *
